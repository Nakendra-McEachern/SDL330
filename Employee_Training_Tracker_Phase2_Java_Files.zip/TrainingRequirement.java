/**
 * Name: Nakendra McEachern
 * Date: August 11, 2026
 * Purpose: Provides shared information and behavior for training requirements.
 */
public abstract class TrainingRequirement implements Trackable {
    private int requirementId;
    private String title;
    private boolean completed;

    public TrainingRequirement(int requirementId, String title, boolean completed) {
        this.requirementId = requirementId;
        this.title = title;
        this.completed = completed;
    }

    public int getRequirementId() {
        return requirementId;
    }

    public String getTitle() {
        return title;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public abstract String getRequirementType();

    @Override
    public String getStatus() {
        return completed ? "Complete" : "Incomplete";
    }

    @Override
    public boolean isExpired() {
        return false;
    }

    @Override
    public String toString() {
        return String.format("[%d] %s: %s | Status: %s",
                requirementId, getRequirementType(), title, getStatus());
    }
}
