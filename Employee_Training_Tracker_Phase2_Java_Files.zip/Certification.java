import java.time.LocalDate;

/**
 * Name: Nakendra McEachern
 * Date: August 11, 2026
 * Purpose: Represents a certification and its expiration information.
 */
public class Certification extends TrainingRequirement {
    private String issuingOrganization;
    private LocalDate expirationDate;

    public Certification(int requirementId, String title, boolean completed,
            String issuingOrganization, LocalDate expirationDate) {
        super(requirementId, title, completed);
        this.issuingOrganization = issuingOrganization;
        this.expirationDate = expirationDate;
    }

    public String getIssuingOrganization() {
        return issuingOrganization;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    @Override
    public String getRequirementType() {
        return "Certification";
    }

    @Override
    public boolean isExpired() {
        return expirationDate != null && expirationDate.isBefore(LocalDate.now());
    }

    @Override
    public String getStatus() {
        if (isExpired()) {
            return "Expired";
        }
        return super.getStatus();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Issuer: %s | Expires: %s",
                issuingOrganization, expirationDate);
    }
}
