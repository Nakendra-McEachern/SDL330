import java.util.ArrayList;

/**
 * Name: Nakendra McEachern
 * Date: August 11, 2026
 * Purpose: Stores an employee and the training requirements assigned to them.
 */
public class Employee {
    private int employeeId;
    private String name;
    private String department;
    private ArrayList<TrainingRequirement> assignedRequirements;

    public Employee(int employeeId, String name, String department) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        assignedRequirements = new ArrayList<>();
    }

    public void assignRequirement(TrainingRequirement requirement) {
        assignedRequirements.add(requirement);
    }

    public ArrayList<TrainingRequirement> getAssignedRequirements() {
        return assignedRequirements;
    }

    @Override
    public String toString() {
        return String.format("Employee ID: %d%nName: %s%nDepartment: %s",
                employeeId, name, department);
    }
}
