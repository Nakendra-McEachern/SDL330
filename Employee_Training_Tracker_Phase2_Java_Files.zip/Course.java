/**
 * Name: Nakendra McEachern
 * Date: August 11, 2026
 * Purpose: Represents a course-based employee training requirement.
 */
public class Course extends TrainingRequirement {
    private String provider;
    private double trainingHours;

    public Course(int requirementId, String title, boolean completed,
            String provider, double trainingHours) {
        super(requirementId, title, completed);
        this.provider = provider;
        this.trainingHours = trainingHours;
    }

    public String getProvider() {
        return provider;
    }

    public double getTrainingHours() {
        return trainingHours;
    }

    @Override
    public String getRequirementType() {
        return "Course";
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Provider: %s | Hours: %.1f",
                provider, trainingHours);
    }
}
