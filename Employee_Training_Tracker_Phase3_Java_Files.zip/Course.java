/**
 * Name: Nakendra McEachern
 * Date: August 16, 2026
 * Purpose: Represents a course-based employee training requirement and
 *          demonstrates overloaded constructors.
 */
public class Course extends TrainingRequirement {
    private String provider;
    private double trainingHours;

    /** No-argument constructor creates a usable sample course. */
    public Course() {
        this(0, "New Employee Orientation", false, "Internal Training", 1.0);
    }

    /** Overloaded constructor creates an incomplete course. */
    public Course(int requirementId, String title, String provider, double trainingHours) {
        this(requirementId, title, false, provider, trainingHours);
    }

    /** Full constructor initializes every course value. */
    public Course(int requirementId, String title, boolean completed,
            String provider, double trainingHours) {
        super(requirementId, title, completed);
        this.provider = provider;
        this.trainingHours = trainingHours;
    }

    public String getProvider() {
        return provider;
    }

    public double getTrainingHours() {
        return trainingHours;
    }

    @Override
    public String getRequirementType() {
        return "Course";
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Provider: %s | Hours: %.1f",
                provider, trainingHours);
    }
}
