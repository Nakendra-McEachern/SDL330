/**
 * Name: Nakendra McEachern
 * Date: August 16, 2026
 * Purpose: Provides the abstract base structure and shared behavior for all
 *          employee training requirements.
 */
public abstract class TrainingRequirement implements Trackable {
    private int requirementId;
    private String title;
    private boolean completed;

    /** No-argument constructor supplies safe starter values. */
    protected TrainingRequirement() {
        this(0, "Untitled Requirement", false);
    }

    /** Overloaded constructor creates a new requirement as incomplete. */
    protected TrainingRequirement(int requirementId, String title) {
        this(requirementId, title, false);
    }

    /** Full constructor lets derived classes initialize all shared fields. */
    protected TrainingRequirement(int requirementId, String title, boolean completed) {
        this.requirementId = requirementId;
        this.title = title;
        this.completed = completed;
    }

    public int getRequirementId() {
        return requirementId;
    }

    public String getTitle() {
        return title;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    // Abstraction requires every child class to identify its requirement type.
    public abstract String getRequirementType();

    // Protected because only this class and its derived classes need this helper.
    protected String getRequirementSummary() {
        return String.format("[%d] %s: %s", requirementId,
                getRequirementType(), title);
    }

    @Override
    public String getStatus() {
        return completed ? "Complete" : "Incomplete";
    }

    @Override
    public boolean isExpired() {
        return false;
    }

    @Override
    public String toString() {
        return getRequirementSummary() + " | Status: " + getStatus();
    }
}
