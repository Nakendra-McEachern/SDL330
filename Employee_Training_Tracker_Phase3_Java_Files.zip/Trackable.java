/**
 * Name: Nakendra McEachern
 * Date: August 16, 2026
 * Purpose: Defines the status behavior shared by trackable training records.
 */
public interface Trackable {
    String getStatus();

    boolean isExpired();
}
