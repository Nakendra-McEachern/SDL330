import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Name: Nakendra McEachern
 * Date: August 16, 2026
 * Purpose: Runs the Week 3 abstraction, constructors, and access specifiers
 *          demonstration for the Employee Training and Certification Tracker.
 */
public class EmployeeTrainingTracker {
    private static final Scanner INPUT = new Scanner(System.in);

    public static void main(String[] args) {
        Employee employee = createSampleEmployee();
        displayWelcome();
        runMenu(employee);
        INPUT.close();
    }

    private static Employee createSampleEmployee() {
        // Full Employee constructor supplies realistic employee information.
        Employee employee = new Employee(1001, "Jordan Lee", "Information Technology");

        // Overloaded Course constructor automatically marks a new course incomplete.
        Course securityCourse = new Course(201, "Cybersecurity Awareness",
                "ECPI Learning Center", 2.5);
        securityCourse.setCompleted(true);

        // Overloaded Certification constructor creates an earned certification.
        Certification javaCertification = new Certification(301,
                "Java Foundations Certification", "Oracle",
                LocalDate.of(2027, 8, 31));
        Certification firstAid = new Certification(302, "First Aid/CPR",
                false, "American Red Cross", LocalDate.of(2026, 7, 15));

        employee.assignRequirement(securityCourse);
        employee.assignRequirement(javaCertification);
        employee.assignRequirement(firstAid);
        return employee;
    }

    private static void displayWelcome() {
        System.out.println("============================================================");
        System.out.println("PROJECT WEEK 3 - ABSTRACTION, CONSTRUCTORS & ACCESS SPECIFIERS");
        System.out.println("Employee Training and Certification Tracker");
        System.out.println("Nakendra McEachern");
        System.out.println("============================================================");
        System.out.println("Welcome! Select a menu number to view employee training");
        System.out.println("information and review the Week 3 OOP demonstration.");
    }

    private static void runMenu(Employee employee) {
        boolean running = true;
        while (running) {
            System.out.println("\n1. View Employee Training Profile");
            System.out.println("2. View All Requirements (Abstraction Demo)");
            System.out.println("3. Exit");
            System.out.print("Enter your selection: ");

            String selection = INPUT.nextLine();
            switch (selection) {
                case "1":
                    displayEmployeeProfile(employee);
                    break;
                case "2":
                    displayRequirements(employee.getAssignedRequirements());
                    break;
                case "3":
                    running = false;
                    System.out.println("Thank you for using the Employee Training Tracker.");
                    break;
                default:
                    System.out.println("Invalid selection. Please enter 1, 2, or 3.");
            }
        }
    }

    private static void displayEmployeeProfile(Employee employee) {
        System.out.println("\n---------------- EMPLOYEE TRAINING PROFILE ----------------");
        System.out.println(employee);
        displayRequirements(employee.getAssignedRequirements());
    }

    private static void displayRequirements(ArrayList<TrainingRequirement> requirements) {
        System.out.println("\n---------------- TRAINING REQUIREMENTS ----------------");

        // Abstraction: child objects are processed through the abstract base type.
        for (TrainingRequirement requirement : requirements) {
            System.out.println(requirement);

            // Interface use: both child types provide Trackable status behavior.
            Trackable trackedItem = requirement;
            System.out.println("    Trackable result: " + trackedItem.getStatus());
        }
    }
}
