import java.time.LocalDate;

/**
 * Name: Nakendra McEachern
 * Date: August 17, 2026
 * Assignment: SDC330L Course Project - Class Implementation
 * Description: Represents a certification, its issuer, expiration information,
 *              and status behavior.
 */
public class Certification extends TrainingRequirement {
    private String issuingOrganization;
    private LocalDate expirationDate;

    /** No-argument constructor creates a basic certification record. */
    public Certification() {
        this(0, "Unassigned Certification", false, "Not Assigned", null);
    }

    /** Overloaded constructor creates a completed certification. */
    public Certification(int requirementId, String title,
            String issuingOrganization, LocalDate expirationDate) {
        this(requirementId, title, true, issuingOrganization, expirationDate);
    }

    /** Full constructor initializes every certification value. */
    public Certification(int requirementId, String title, boolean completed,
            String issuingOrganization, LocalDate expirationDate) {
        super(requirementId, title, completed);
        this.issuingOrganization = issuingOrganization;
        this.expirationDate = expirationDate;
    }

    public String getIssuingOrganization() {
        return issuingOrganization;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    @Override
    public String getRequirementType() {
        return "Certification";
    }

    @Override
    public boolean isExpired() {
        return expirationDate != null && expirationDate.isBefore(LocalDate.now());
    }

    @Override
    public String getStatus() {
        if (isExpired()) {
            return "Expired";
        }
        return super.getStatus();
    }

    @Override
    public String toString() {
        return super.toString() + String.format(" | Issuer: %s | Expires: %s",
                issuingOrganization, expirationDate);
    }
}
