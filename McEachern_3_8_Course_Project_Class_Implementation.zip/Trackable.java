/**
 * Name: Nakendra McEachern
 * Date: August 17, 2026
 * Assignment: SDC330L Course Project - Class Implementation
 * Description: Defines the status behavior shared by trackable training records.
 */
public interface Trackable {
    String getStatus();

    boolean isExpired();
}
