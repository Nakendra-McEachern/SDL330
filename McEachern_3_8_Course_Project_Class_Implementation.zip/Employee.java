import java.util.ArrayList;

/**
 * Name: Nakendra McEachern
 * Date: August 17, 2026
 * Assignment: SDC330L Course Project - Class Implementation
 * Description: Stores protected employee data and the training requirements
 *              assigned to the employee through composition.
 */
public class Employee {
    private int employeeId;
    private String name;
    private String department;
    private final ArrayList<TrainingRequirement> assignedRequirements;

    /** No-argument constructor supplies safe default employee information. */
    public Employee() {
        this(0, "New Employee", "Unassigned");
    }

    /** Overloaded constructor assigns a default department. */
    public Employee(int employeeId, String name) {
        this(employeeId, name, "General");
    }

    /** Full constructor initializes the employee and its empty requirement list. */
    public Employee(int employeeId, String name, String department) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        assignedRequirements = new ArrayList<>();
    }

    public void assignRequirement(TrainingRequirement requirement) {
        if (requirement != null) {
            assignedRequirements.add(requirement);
        }
    }

    public ArrayList<TrainingRequirement> getAssignedRequirements() {
        return new ArrayList<>(assignedRequirements);
    }

    @Override
    public String toString() {
        return String.format("Employee ID: %d%nName: %s%nDepartment: %s",
                employeeId, name, department);
    }
}
