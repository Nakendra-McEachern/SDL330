/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Runs the Project Week 1 console interface and demonstrates
 * inheritance, composition, user input, and formatted output.
 */
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("============================================================");
        System.out.println("PROJECT WEEK 1 - INHERITANCE, COMPOSITION, AND USER INTERACTIONS");
        System.out.println("Employee Training and Certification Tracker");
        System.out.println("Created by Nakendra McEachern");
        System.out.println("============================================================");
        System.out.println("Welcome! This application tracks employee training and");
        System.out.println("certification requirements. Enter a menu number to continue.");

        Employee employee = new Employee(
            "E1001", "Alicia Johnson", "Human Resources", "HR Data Analyst");

        // Inheritance: Course and Certification are child classes of
        // the TrainingRequirement base class.
        Course securityCourse = new Course(
            "Data Security Awareness", "Compliance", "Completed", 2);
        Certification workdayCertification = new Certification(
            "Workday Reporting Certification", "Professional Development",
            "Approaching Expiration", "December 15, 2026");

        // Composition: the Employee object contains assigned requirements.
        employee.addRequirement(securityCourse);
        employee.addRequirement(workdayCertification);

        boolean running = true;
        while (running) {
            displayMenu();
            System.out.print("Enter your selection: ");
            String selection = input.nextLine();

            switch (selection) {
                case "1":
                    System.out.println("\nEMPLOYEE PROFILE");
                    System.out.println("------------------------------");
                    System.out.println(employee.getProfile());
                    break;
                case "2":
                    System.out.println("\nASSIGNED TRAINING REQUIREMENTS");
                    System.out.println("------------------------------");
                    System.out.println(employee.getRequirementDetails());
                    break;
                case "3":
                    System.out.println("\nThank you for using the Employee Training Tracker.");
                    System.out.println("Application closed successfully.");
                    running = false;
                    break;
                default:
                    System.out.println("\nInvalid selection. Please enter 1, 2, or 3.");
            }
        }

        input.close();
    }

    public static void displayMenu() {
        System.out.println("\nMAIN MENU");
        System.out.println("1. View Employee Profile");
        System.out.println("2. View Assigned Training Requirements");
        System.out.println("3. Exit Application");
    }
}
