/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Represents a general employee training requirement and serves
 * as the base class for Course and Certification objects.
 */
public abstract class TrainingRequirement implements Reportable {
    private String requirementName;
    private String category;
    private String status;

    public TrainingRequirement(String requirementName, String category,
            String status) {
        this.requirementName = requirementName;
        this.category = category;
        this.status = status;
    }

    public String getRequirementName() {
        return requirementName;
    }

    public void setRequirementName(String requirementName) {
        this.requirementName = requirementName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String getStatusSummary() {
        return requirementName + " - " + status;
    }

    @Override
    public String toString() {
        return String.format("Requirement: %s%nCategory: %s%nStatus: %s",
            requirementName, category, status);
    }
}
