/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Represents a training course derived from the general
 * TrainingRequirement base class.
 */
public class Course extends TrainingRequirement {
    private int durationHours;

    public Course(String requirementName, String category, String status,
            int durationHours) {
        super(requirementName, category, status);
        this.durationHours = durationHours;
    }

    public int getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(int durationHours) {
        this.durationHours = durationHours;
    }

    @Override
    public String toString() {
        return String.format("%s%nType: Course%nDuration: %d hours",
            super.toString(), durationHours);
    }
}
