/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Represents an employee and contains the training requirements
 * assigned to that employee.
 */
import java.util.ArrayList;

public class Employee {
    private String employeeId;
    private String name;
    private String department;
    private String jobTitle;

    // Composition: an Employee has a collection of TrainingRequirement objects.
    private ArrayList<TrainingRequirement> assignedRequirements;

    public Employee(String employeeId, String name, String department,
            String jobTitle) {
        this.employeeId = employeeId;
        this.name = name;
        this.department = department;
        this.jobTitle = jobTitle;
        assignedRequirements = new ArrayList<TrainingRequirement>();
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public ArrayList<TrainingRequirement> getAssignedRequirements() {
        return assignedRequirements;
    }

    public void addRequirement(TrainingRequirement requirement) {
        assignedRequirements.add(requirement);
    }

    public String getProfile() {
        return String.format(
            "Employee ID: %s%nName: %s%nDepartment: %s%nJob Title: %s%n"
                + "Assigned Requirements: %d",
            employeeId, name, department, jobTitle,
            assignedRequirements.size());
    }

    public String getRequirementDetails() {
        String details = "";
        for (int index = 0; index < assignedRequirements.size(); index++) {
            // Polymorphism: Course and Certification objects are processed
            // through their shared TrainingRequirement type.
            TrainingRequirement requirement = assignedRequirements.get(index);
            details += String.format("%nRequirement %d%n%s%n",
                index + 1, requirement);
        }
        return details;
    }
}
