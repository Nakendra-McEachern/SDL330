/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Defines the reporting behavior used by training requirements.
 */
public interface Reportable {
    String getStatusSummary();
}
