/*******************************************************************
 * Name: Nakendra McEachern
 * Date: August 2, 2026
 * Purpose: Represents a professional certification derived from the
 * general TrainingRequirement base class.
 */
public class Certification extends TrainingRequirement {
    private String expirationDate;

    public Certification(String requirementName, String category,
            String status, String expirationDate) {
        super(requirementName, category, status);
        this.expirationDate = expirationDate;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String toString() {
        return String.format("%s%nType: Certification%nExpiration Date: %s",
            super.toString(), expirationDate);
    }
}
